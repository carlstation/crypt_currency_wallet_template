# Addax crypt_currency_web_wallet_template
template for crypto currency website app
